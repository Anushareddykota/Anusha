<?php
$conn=oci_connect("system","reena","localhost/XE");
$a = $_POST['comp_id'];
$b = $_POST['status'];
$check="UPDATE COMPLAINT SET comp_status='$b' where comp_id='$a'";
$res1=oci_parse($conn,$check);
oci_execute($res1);
echo "Status updated";
?>