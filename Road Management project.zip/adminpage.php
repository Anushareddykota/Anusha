<!doctype html>
<head><title>welcome</title></head>

<body background="admin.jpg" style="background-size:1270px;">
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #339EFF;
}

.topnav a {
  float: left;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color:#33E8FF;
  color: white;
}

.topnav a.active {
  background-color:;
  color: white;
}
</style>
</head>
<body>



<div style="padding-left:16px">
  
</div>

</body>
</html>

<div class="topnav">
  <a class="active" href="viewcomplaint.php">VIEW ALL COMPLAINTS</a>
  <a href="viewadcom.php">COMPLAINTS TO SUPERVISE</a>
  <a href="adminmanageciti.php">MANAGE CITIZEN</a>
  <a href="adminmanageauth.php">MANAGE AUTHORITY</a>
  <a href="deletecom.php">DELETE COMPLAINT</a>
  <a href="votecount1.php">VIEW VOTES</a>
  <a href="adminprof.php">VIEW PROFILE</a>
  <a href="buddis.php">VIEW BUDGET DETAILS</a>
  
</div>



 











</body>
</html>