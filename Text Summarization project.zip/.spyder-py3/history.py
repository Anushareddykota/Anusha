# -*- coding: utf-8 -*-
# *** Spyder Python Console History Log ***

## ---(Sun Oct 20 10:42:27 2019)---
runfile('C:/Users/Sreek/.spyder-py3/textsumcode.py', wdir='C:/Users/Sreek/.spyder-py3')
summary = " ".join(str(x) for x in sentence_list)
print(summary)
# save the data in another file, names sum.txt
f = open('sum.txt', 'a+')
#print(type(f))
f.write('-------------------\n')
f.write(summary)
f.write('\n')

f.close
runfile('C:/Users/Sreek/.spyder-py3/textsumcode.py', wdir='C:/Users/Sreek/.spyder-py3')
pip install PyPDF2
runfile('C:/Users/Sreek/.spyder-py3/textsumcode.py', wdir='C:/Users/Sreek/.spyder-py3')
pip install PyPDF2
runfile('C:/Users/Sreek/.spyder-py3/textsumcode.py', wdir='C:/Users/Sreek/.spyder-py3')
spyder --reset
reset
runfile('C:/Users/Sreek/.spyder-py3/textsumcode.py', wdir='C:/Users/Sreek/.spyder-py3')

## ---(Sun Oct 20 11:35:24 2019)---
runfile('C:/Users/Sreek/.spyder-py3/textsumcode.py', wdir='C:/Users/Sreek/.spyder-py3')
runfile('C:/Users/Sreek/.spyder-py3/textsumcode.py', wdir='C:/Users/Sreek/.spyder-py3')
runfile('C:/Users/Sreek/.spyder-py3/textsumcode.py', wdir='C:/Users/Sreek/.spyder-py3')
runfile('C:/Users/Sreek/.spyder-py3/textsumcode.py', wdir='C:/Users/Sreek/.spyder-py3')
runfile('C:/Users/Sreek/.spyder-py3/textsumcode.py', wdir='C:/Users/Sreek/.spyder-py3')
runfile('C:/Users/Sreek/Anaconda3/lib/encodings/cp1252.py', wdir='C:/Users/Sreek/Anaconda3/lib/encodings')
runfile('C:/Users/Sreek/.spyder-py3/textsumcode.py', wdir='C:/Users/Sreek/.spyder-py3')

## ---(Sun Oct 20 19:02:47 2019)---
summary = " ".join(str(x) for x in sentence_list)
print("FINAL SUMMARY OF YOUR DOCUMENT:")
print(summary)
# save the data in another file, names sum.txt
f = open('finalsummary.txt', 'a+')
#print(type(f))
f.write('\n-------------------\n\n')
f.write(summary)
f.write('\n')

f.close
runfile('C:/Users/Sreek/.spyder-py3/textsumcode.py', wdir='C:/Users/Sreek/.spyder-py3')

## ---(Wed Oct 23 08:57:08 2019)---
runfile('C:/Users/Sreek/.spyder-py3/textsumcode.py', wdir='C:/Users/Sreek/.spyder-py3')


runfile('C:/Users/Sreek/.spyder-py3/textsumcode.py', wdir='C:/Users/Sreek/.spyder-py3')

## ---(Wed Oct 23 15:05:38 2019)---
runfile('C:/Users/Sreek/.spyder-py3/textsumcode.py', wdir='C:/Users/Sreek/.spyder-py3')
runfile('C:/Users/Sreek/.spyder-py3/textsumcode.py', wdir='C:/Users/Sreek/.spyder-py3')