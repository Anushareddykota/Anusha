import re


regex_str = [
    r'<[^>]+>', # HTML tags
    r'(?:@[\w_]+)', # @-mentions
    r"(?:\#+[\w_]+[\w\'_\-]*[\w_]+)", # hash-tags
    r'http[s]?://(?:[a-z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-f][0-9a-f]))+', # URLs
 
    r'(?:(?:\d+,?)+(?:\.?\d+)?)', # numbers
    r"(?:[a-z][a-z'\-_]+[a-z])", # words with - and '
    r'(?:[\w_]+)', # other words
    r'(?:\S)+' # anything else
]

tokens_re = re.compile(r'('+'|'.join(regex_str)+')', re.VERBOSE | re.IGNORECASE)

def tokenize(s):
    return tokens_re.findall(s)

def preprocess(s,l,lowercase=True):
    tokens = tokenize(s)
    tokens = [token.lower() for token in tokens]
    html_regex = re.compile('<[^>]+>')
    tokens = [token for token in tokens if not html_regex.match(token)]
    mention_regex = re.compile('(?:@[\w_]+)')
    tokens = ['' if mention_regex.match(token) else token for token in tokens]

    url_regex = re.compile('http[s]?://(?:[a-z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-f][0-9a-f]))+')
    tokens = ['' if url_regex.match(token) else token for token in tokens]
    #geolocation
    ts = tokenize(l)
    ts = [token.lower() for token in ts]
    html_regex = re.compile('<[^>]+>')
    ts = [token for token in ts if not html_regex.match(token)]
    mention_regex = re.compile('(?:@[\w_]+)')
    ts = ['' if mention_regex.match(token) else token for token in ts]

    url_regex = re.compile('http[s]?://(?:[a-z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-f][0-9a-f]))+')
    ts = ['' if url_regex.match(token) else token for token in ts]
    hashtag_regex = re.compile("(?:\#+[\w_]+[\w\'_\-]*[\w_]+)")
    
    #tokens = ['' if hashtag_regex.match(token) else token for token in tokens]
    flag = False
    for item in tokens:
        if item=='rt':
            flag = True
            continue
        if flag and item=='@user':
            return ''
        else:
            flag = False
    tweet=((' '.join([t for t in tokens if t]).replace('rt','')).replace(':','')).replace('#',' ')
    l=(''.join([k for k in ts if k])).replace('#','')
    #hash_tag.append('        ')
   # print(type(len(tweet)))
    #for i in tweet : 
    #    hash_tag.append(i)
    s=""
    s=tweet
    return ((s).replace('#','')).replace('"','')
    #print((' '.join([t for t in tokens if t]).replace('rt','')).replace(':',''))
    #return (' '.join([t for t in tokens if t]).replace('rt','')).replace(':','
