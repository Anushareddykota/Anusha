# -*- coding: utf-8 -*-
"""
Created on Wed Jun 26 10:48:02 2019

@author: Sreek
"""

from nltk.tokenize import sent_tokenize, word_tokenize 
import warnings
import io
import math
import sys
warnings.filterwarnings(action = 'ignore') 
import numpy as np
import sklearn
from sklearn.metrics.pairwise import cosine_similarity 
import gensim 
from gensim.models import Word2Vec 
def myfunction(tweet,loc):
    with open("500tweets.txt",encoding='utf-8') as f:
        s=([line.split() for line in f])
        l=len(s)
        model = Word2Vec(s, min_count=1,size = 100, window = 2)
        avg_vec=[]
        for i in s:
            for j in i:
                vec=(model[j])
                for k in i:
                    numberlist=[]
                    numberlist=(model[i])
                    s=sum(numberlist)
            l=len(i)
            average=s/l
            avg_vec.append(average)
    geo_vec=[]   
    sample = open("500locs.txt",encoding='utf-8') 
    s = sample.read()  
    f = s.replace("\n", " ") 
    data = [] 
    for i in sent_tokenize(f): 
        temp = [] 
        
        # tokenize the sentence into words 
        for j in word_tokenize(i): 
            temp.append(j.lower()) 

        data.append(temp) 
    sentences=data
    model = Word2Vec(sentences, min_count=1,size = 100, window = 2)
    words = list(model.wv.vocab)
    for i in words:
        vector=(model[i])
        geo_vec.append(vector)
        
    #print("concatenated vector of location vector and corresponding tweet vector")  
    x = avg_vec
    y = geo_vec
    zipped = zip(x, y)
    ll=(list((zipped)))
    #print(ll)
    avgvec=[]
    #print("Reading file with Unknown preprocessed tweet.........")
    with open("unknowntweet.txt",encoding='utf-8') as f:
        t=tweet
        t=([line.split() for line in f])
        print(t)
        #print("Unknown tweet is:",s)
        l=len(t)
        #print("Length of tweet is:",l)
        print("\n")
        model = Word2Vec(t, min_count=1,size = 100, window = 2)
        #print(model)
        for i in t:
            #print(i)
            for j in i:
                #print(j)
                vec=(model[j])
                for k in i:
                    numberlist=[]
                    numberlist=(model[i])
                    t=sum(numberlist)
            #print("sum of all vectors:",s)
            l=len(i)
            #print("length of tweet is",l)
            average=t/l
            #print("average of all vectors:",average)
            avgvec.append(average)
            
    #print(avgvec)

    with open("unknownloctweet.txt",encoding='utf-8') as f:
        loc=([line.split() for line in f])
        #print("Unknown tweet is:",s)
        l=len(loc)
        #print("Length of tweet is:",l)
        print("\n")
        model = Word2Vec(loc, min_count=1,size = 100, window = 2)
        #print(model)
        for i in loc:
            #print(i)
            for j in i:
                #print(j)
                vec=(model[j])
                for k in i:
                    numberlist=[]
                    numberlist=(model[i])
                    loc=sum(numberlist)
            #print("sum of all vectors:",s)
            l=len(i)
            #print("length of tweet is",l)
            average=loc/l
            #print("average of all vectors:",average)
            avgvec.append(average)
    
    #print(avgvec)
    v1=[]
    v2=[]
    op=[]
    li=[]
    print("\n")
    #print("Finding Cosine Similarity Between 500 tweets & Unknown Tweet..........")
    def cosine_similarity(v1,v2):
        "compute cosine similarity of v1 to v2: (v1 dot v2)/{||v1||*||v2||)"
        sumxx, sumxy, sumyy = 0, 0, 0
        for i in range(len(v1)):
            x = v1[i]; y = v2[i]
            sumxx += x*x
            sumyy += y*y
            sumxy += x*y
        return sumxy/math.sqrt(sumxx*sumyy)
    for i in range(len(avgvec)):
        v1=avgvec[i]
        for j in range(i,len(avg_vec)):
            v2=avg_vec[j]
            op=cosine_similarity(v1,v2)
            #print(op)
            li.append(op)
                    
   # print("List of all cosine similarities:",li)
    print("\n")
    length=len(li)
    #print("length of all cosine similarities:",length)
    print("\n")   
    print("\n")   
    test_list=li
    k=[]
   # print ("List index-value are : ") 
    for i in range(len(test_list)): 
        k.append([i,test_list[i]]) 
   # print(k)
    def Sort(sub_li): 
        l = len(sub_li) 
        for i in range(0, l): 
            for j in range(0, l-i-1): 
                if (sub_li[j][1] > sub_li[j + 1][1]): 
                    tempo = sub_li[j] 
                    sub_li[j]= sub_li[j + 1] 
                    sub_li[j + 1]= tempo 
        return sub_li  
    sub_li =k
    #print("\n")
    #print(Sort(sub_li))
    #print("\n")
    mylist=sub_li
    #print(mylist)
    mylist.reverse()
    #print("\n")
    #print(mylist)
    #print("\n")
    #print("First 20 cosine similarities:",mylist[:20])
    with open("usatweets500.txt") as f: 
        x = f.readlines()
    text =x[204]
    print(text)
    st=[]
    t=[]
    def get_hashtags(text, order=False):
        tags = set([item.strip("#.,-\"\'&*^!") for item in text.split() if (item.startswith("#") and len(item) < 256)])
        print(tags)
        return sorted(tags) if order else tags
    st=get_hashtags(text, True)
    t= ["#" + i for i in st]
    print(st)
    return t

def main(a,b):
    tweet=a
    loc=b
    with io.open("unknowntweet.txt",'w',encoding='UTF-8') as f:
        f.write(tweet)
    with io.open("unknownloctweet.txt",'w',encoding='UTF-8') as f:
        f.write(loc)
    return myfunction(tweet,loc) 
    #print(k)
    #print("wgreqgre")
    #return k 
if __name__ == "__main__":
    main(sys.argv[1:])