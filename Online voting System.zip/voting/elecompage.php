<!doctype html>
<head><title>welcome</title></head>

<body background="ec.jpg" style="background-size:1270px;">
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #339EFF;
}

.topnav a {
  float: left;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color:#33E8FF;
  color: white;
}

.topnav a.active {
  background-color:;
  color: white;
}
</style>
</head>
<body>



<div style="padding-left:16px">
  
</div>

</body>
</html>

<div class="topnav">
  <a class="active" href="makeaanounce.php">Make Announcements</a>
  <a href="appcand.php">Candidate Application</a>
  <a href="dispcandidate.php">Display Candidate List</a>
   <a href="dispvoter.php">Display Voter List</a>
  <a href="rescount.php">Results</a>
  </div>

</body>
</html>